<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'sqlite:/home/vaisakhkv/basic/local.sqlite',
    /*'dsn'=>'mysql:host=localhost;dbname=basictest',
    /*'username' => 'basictest',
    'password' => 'localpassword',*/	
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
